import { Routes } from '@angular/router';
import { DistanceComponent } from './distance/distance.component';
import { SipComponent } from './sip/sip.component';

export const routes: Routes = [
  {
    path:'',
    component:DistanceComponent
  },
  {
    path:'sip',
    component:SipComponent
  },
  {
    path:'**',
    component:DistanceComponent
  }
];
